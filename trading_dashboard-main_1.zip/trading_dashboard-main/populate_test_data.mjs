// Script para popular dados de teste no localStorage
// Execute: node populate_test_data.mjs

const assets = ["EUR/USD", "USDJPY", "XAUUSD", "NASDAQ", "BTC USD"];
const sessions = ["Manhã", "Tarde", "Noite"];
const results = ["WIN", "LOSS", "BREAK_EVEN"];

function generateTestTrades() {
  const trades = [];
  const startDate = new Date(2026, 1, 1); // Fevereiro 1, 2026
  
  // Gerar trades para 4 semanas
  for (let dayOffset = 0; dayOffset < 28; dayOffset++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(currentDate.getDate() + dayOffset);
    
    // Pular fins de semana
    const dayOfWeek = currentDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;
    
    // Gerar 1-3 trades por dia
    const tradesPerDay = Math.floor(Math.random() * 3) + 1;
    
    for (let i = 0; i < tradesPerDay; i++) {
      const result = results[Math.floor(Math.random() * results.length)];
      const riskReward = result === "WIN" ? Math.floor(Math.random() * 4) + 1 : -1;
      const moneyResult = result === "WIN" 
        ? Math.floor(Math.random() * 100) + 20 
        : result === "LOSS" 
          ? -(Math.floor(Math.random() * 50) + 10)
          : 0;
      
      const trade = {
        id: `trade_${Date.now()}_${Math.random()}`,
        date: currentDate.toISOString().split('T')[0],
        entryTime: `${String(Math.floor(Math.random() * 24)).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
        asset: assets[Math.floor(Math.random() * assets.length)],
        entryPrice: (Math.random() * 100 + 1).toFixed(5),
        exitPrice: (Math.random() * 100 + 1).toFixed(5),
        stopLoss: (Math.random() * 100 + 1).toFixed(5),
        takeProfit: (Math.random() * 100 + 1).toFixed(5),
        resultPrice: (Math.random() * 100 + 1).toFixed(5),
        session: sessions[Math.floor(Math.random() * sessions.length)],
        marketSession: "Automático",
        account: "Conta 1",
        result: result,
        riskReward: riskReward,
        moneyResult: moneyResult,
        notes: `Trade de teste - ${result}`,
        isFavorite: Math.random() > 0.7, // 30% de chance de ser favorito
        preTradeImage: undefined,
        tradingImage: undefined,
        postTradeImage: undefined,
        operational: {
          environment: true,
          mentalReadiness: true,
          emotionalReadiness: true,
          objectiveClarity: true,
        },
        emotional: {
          confident: Math.random() > 0.5,
          anxious: Math.random() > 0.7,
          focused: Math.random() > 0.3,
          impulsive: Math.random() > 0.8,
        },
        rational: {
          followedPlan: Math.random() > 0.2,
          managedRisk: Math.random() > 0.1,
          respectedLimits: Math.random() > 0.2,
          analyzedSetup: Math.random() > 0.1,
        },
        createdAt: currentDate.getTime(),
      };
      
      trades.push(trade);
    }
  }
  
  return trades;
}

// Gerar dados
const testTrades = generateTestTrades();

// Simular localStorage (para Node.js)
const localStorage = {
  data: {},
  setItem(key, value) {
    this.data[key] = value;
  },
  getItem(key) {
    return this.data[key] || null;
  },
};

// Salvar dados
localStorage.setItem('trades_enhanced_Conta 1', JSON.stringify(testTrades));

// Exibir resumo
console.log(`✅ Dados de teste criados com sucesso!`);
console.log(`📊 Total de trades: ${testTrades.length}`);
console.log(`📅 Período: Fevereiro 2026`);
console.log(`💰 Saldo total: $${testTrades.reduce((sum, t) => sum + t.moneyResult, 0).toFixed(2)}`);
console.log(`🎯 Taxa de acerto: ${((testTrades.filter(t => t.result === 'WIN').length / testTrades.length) * 100).toFixed(1)}%`);
console.log(`\n📋 Dados salvos em localStorage['trades_enhanced_Conta 1']`);
console.log(`\n⚠️  Para usar estes dados no navegador:`);
console.log(`1. Abra o DevTools (F12)`);
console.log(`2. Vá para Console`);
console.log(`3. Cole o seguinte código:`);
console.log(`\nlocalStorage.setItem('trades_enhanced_Conta 1', '${JSON.stringify(testTrades)}');`);
console.log(`\n4. Recarregue a página (F5)`);
