import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// TODO: Add your tables here
import { decimal, mysqlTable as table } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

// Tabela de Contas de Trading
export const tradingAccounts = table("trading_accounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: text("name").notNull(),
  currentBalance: decimal("currentBalance", { precision: 12, scale: 2 }).default("0"),
  isActive: int("isActive").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TradingAccount = typeof tradingAccounts.$inferSelect;
export type InsertTradingAccount = typeof tradingAccounts.$inferInsert;

// Tabela de Trades
export const trades = table("trades", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  accountId: int("accountId").notNull(),
  asset: varchar("asset", { length: 50 }).notNull(),
  entryPrice: decimal("entryPrice", { precision: 12, scale: 5 }),
  stopLossPrice: decimal("stopLossPrice", { precision: 12, scale: 5 }),
  takeProfitPrice: decimal("takeProfitPrice", { precision: 12, scale: 5 }),
  exitPrice: decimal("exitPrice", { precision: 12, scale: 5 }),
  result: varchar("result", { length: 20 }), // 'win', 'loss', 'draw', 'ongoing'
  moneyResult: decimal("moneyResult", { precision: 12, scale: 2 }),
  pips: decimal("pips", { precision: 10, scale: 2 }),
  ticks: int("ticks"),
  riskReward: decimal("riskReward", { precision: 5, scale: 2 }),
  stopLossDollars: decimal("stopLossDollars", { precision: 12, scale: 2 }),
  takeProfitDollars: decimal("takeProfitDollars", { precision: 12, scale: 2 }),
  executedAt: timestamp("executedAt"),
  session: varchar("session", { length: 20 }), // 'morning', 'afternoon', 'night'
  isFavorite: int("isFavorite").default(0),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

// Tabela de Análises
export const analyses = table("analyses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  asset: varchar("asset", { length: 50 }).notNull(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  status: varchar("status", { length: 20 }), // 'active', 'tested', 'discarded'
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = typeof analyses.$inferInsert;

// Relações
export const usersRelations = relations(users, ({ many }) => ({
  tradingAccounts: many(tradingAccounts),
  trades: many(trades),
  analyses: many(analyses),
}));

export const tradingAccountsRelations = relations(tradingAccounts, ({ one, many }) => ({
  user: one(users, {
    fields: [tradingAccounts.userId],
    references: [users.id],
  }),
  trades: many(trades),
}));

export const tradesRelations = relations(trades, ({ one }) => ({
  user: one(users, {
    fields: [trades.userId],
    references: [users.id],
  }),
  account: one(tradingAccounts, {
    fields: [trades.accountId],
    references: [tradingAccounts.id],
  }),
}));

export const analysesRelations = relations(analyses, ({ one }) => ({
  user: one(users, {
    fields: [analyses.userId],
    references: [users.id],
  }),
}));
