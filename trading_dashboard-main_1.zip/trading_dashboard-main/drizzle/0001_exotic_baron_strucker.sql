CREATE TABLE `analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`asset` varchar(50) NOT NULL,
	`description` text,
	`imageUrl` text,
	`status` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`accountId` int NOT NULL,
	`asset` varchar(50) NOT NULL,
	`entryPrice` decimal(12,5),
	`stopLossPrice` decimal(12,5),
	`takeProfitPrice` decimal(12,5),
	`exitPrice` decimal(12,5),
	`result` varchar(20),
	`moneyResult` decimal(12,2),
	`pips` decimal(10,2),
	`ticks` int,
	`riskReward` decimal(5,2),
	`stopLossDollars` decimal(12,2),
	`takeProfitDollars` decimal(12,2),
	`executedAt` timestamp,
	`session` varchar(20),
	`isFavorite` int DEFAULT 0,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trading_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` text NOT NULL,
	`currentBalance` decimal(12,2) DEFAULT '0',
	`isActive` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trading_accounts_id` PRIMARY KEY(`id`)
);
