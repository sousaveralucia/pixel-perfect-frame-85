import { useState, useMemo, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useTradeJournal, calculateDuration, detectSessionByAsset, calculateStopLossInDollars, calculateProfitLossByContract, Trade } from "@/hooks/useTradeJournal";
import { useAccountManager } from "@/hooks/useAccountManager";
import { BookOpen, Plus, Download, Trash2, Edit2, Star, Image, ZoomIn, ZoomOut, Pen } from "lucide-react";

export default function TradeJournal() {
  const { trades, isLoaded, addTrade, updateTrade, deleteTrade, toggleFavorite, getStatistics, exportAsJSON, exportAsCSV } = useTradeJournal();
  const { accounts, activeAccountId, switchAccount } = useAccountManager();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ url: string; title: string } | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterSession, setFilterSession] = useState<string>("all");
  const [filterFavorites, setFilterFavorites] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [showDrawTools, setShowDrawTools] = useState(false);
  const [drawColor, setDrawColor] = useState('#FF0000');
  const [drawSize, setDrawSize] = useState(3);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [preTradeChecklist, setPreTradeChecklist] = useState({
    fibonacciConfirmed: false,
    obRefined: false,
    chochValid: false,
    riskRewardValid: false,
  });

  // Form state - novo formato baseado em tamanho de contrato
  const [formData, setFormData] = useState({
    accountId: activeAccountId,
    entryDateTime: "",
    exitDateTime: "",
    asset: "GBP/USD",
    type: "BUY" as "BUY" | "SELL",
    entryPrice: "",
    exitPrice: "",
    stopPrice: "",
    contractSize: "",
    takeProfit: "",
    entryReason: "50% OB - Execução Direta" as "50% OB - Execução Direta" | "Primeiro Toque - Alinhamento de Fluxo",
    status: "GANHO" as "GANHO" | "PERDA" | "CANCELADO",
    notes: "",
    preTradeImage: "",
    tradingImage: "",
    postTradeImage: "",
  });

  let filteredTrades = trades.filter((trade) => {
    if (trade.accountId !== activeAccountId) return false; // Filtrar por conta ativa
    if (filterAsset !== "all" && trade.asset !== filterAsset) return false;
    if (filterStatus !== "all" && trade.status !== filterStatus) return false;
    if (filterSession !== "all" && trade.session !== filterSession) return false;
    if (filterFavorites && !trade.isFavorite) return false;
    return true;
  });

  // Calcular stats apenas para filteredTrades
  const stats = (() => {
    if (filteredTrades.length === 0) {
      return {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        winRate: 0,
        totalProfit: 0,
      };
    }
    const winning = filteredTrades.filter((t) => t.status === "GANHO");
    const losing = filteredTrades.filter((t) => t.status === "PERDA");
    const totalProfit = winning.reduce((sum, t) => sum + t.profitLoss, 0);
    return {
      totalTrades: filteredTrades.length,
      winningTrades: winning.length,
      losingTrades: losing.length,
      winRate: ((winning.length / (winning.length + losing.length)) * 100).toFixed(2),
      totalProfit: totalProfit.toFixed(2),
    };
  })();

  const handleAddTrade = () => {
    if (!formData.entryDateTime || !formData.exitDateTime) {
      alert("Preencha data/hora de entrada e saída");
      return;
    }

    const entryDate = new Date(formData.entryDateTime);
    const exitDate = new Date(formData.exitDateTime);

    const newTrade: any = {
      id: editingId || Date.now().toString(),
      accountId: formData.accountId,
      entryDateTime: entryDate.toISOString(),
      exitDateTime: exitDate.toISOString(),
      asset: formData.asset,
      type: formData.type,
      entryPrice: Number(formData.entryPrice),
      exitPrice: Number(formData.exitPrice),
      stopPrice: Number(formData.stopPrice),
      contractSize: Number(formData.contractSize),
      takeProfit: Number(formData.takeProfit),
      entryReason: formData.entryReason,
      status: formData.status,
      notes: formData.notes,
      preTradeImage: formData.preTradeImage,
      tradingImage: formData.tradingImage,
      postTradeImage: formData.postTradeImage,
      session: detectSessionByAsset(entryDate, formData.asset),
      isFavorite: editingId ? trades.find(t => t.id === editingId)?.isFavorite || false : false,
      stopLossInDollars: calculateStopLossInDollars(Number(formData.entryPrice), Number(formData.stopPrice), Number(formData.contractSize)),
      profitLoss: calculateProfitLossByContract(Number(formData.entryPrice), Number(formData.exitPrice), Number(formData.contractSize), formData.type).profitLoss,
      profitLossPercent: calculateProfitLossByContract(Number(formData.entryPrice), Number(formData.exitPrice), Number(formData.contractSize), formData.type).profitLossPercent,
      pipsGained: calculateProfitLossByContract(Number(formData.entryPrice), Number(formData.exitPrice), Number(formData.contractSize), formData.type).pipsGained,
      duration: calculateDuration(entryDate.toISOString(), exitDate.toISOString()),
      createdAt: new Date().toISOString(),
    };

    if (editingId) {
      updateTrade(editingId, newTrade);
      setEditingId(null);
    } else {
      addTrade(newTrade);
    }

    setFormData({
      accountId: activeAccountId,
      entryDateTime: "",
      exitDateTime: "",
      asset: "GBP/USD",
      type: "BUY",
      entryPrice: "",
      exitPrice: "",
      stopPrice: "",
      contractSize: "",
      takeProfit: "",
      entryReason: "50% OB - Execução Direta",
      status: "GANHO",
      notes: "",
      preTradeImage: "",
      tradingImage: "",
      postTradeImage: "",
    });
    setIsOpen(false);
  };

  const handleEditTrade = (trade: Trade) => {
    setFormData({
      accountId: trade.accountId,
      entryDateTime: String(trade.entryDateTime).slice(0, 16),
      exitDateTime: String(trade.exitDateTime).slice(0, 16),
      asset: trade.asset,
      type: trade.type,
      entryPrice: trade.entryPrice.toString(),
      exitPrice: trade.exitPrice.toString(),
      stopPrice: trade.stopPrice.toString(),
      contractSize: trade.contractSize.toString(),
      takeProfit: trade.takeProfit.toString(),
      entryReason: trade.entryReason,
      status: trade.status,
      notes: trade.notes,
      preTradeImage: trade.preTradeImage || "",
      tradingImage: trade.tradingImage || "",
      postTradeImage: trade.postTradeImage || "",
    });
    setEditingId(trade.id);
    setIsOpen(true);
  };

  // Canvas drawing functions
  useEffect(() => {
    if (!canvasRef.current || !selectedImage) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Load image
    const img = new (window as any).Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
    };
    img.src = selectedImage.url;
  }, [selectedImage]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = drawColor;
    ctx.lineWidth = drawSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) ctx.closePath();
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            Diário de Trades
          </CardTitle>
          <CardDescription>Registre e acompanhe todas as suas operações</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Seletor de Conta */}
          <div className="flex items-center gap-4 p-4 bg-secondary/50 rounded-lg border border-border">
            <Label className="font-semibold">Conta Ativa:</Label>
            <Select value={activeAccountId} onValueChange={switchAccount}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    Conta ${account.initialBalance} (Saldo: ${account.currentBalance.toFixed(2)})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Novo Trade Button */}
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90" onClick={() => setEditingId(null)}>
                <Plus className="w-4 h-4 mr-2" />
                Novo Trade
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
              <DialogHeader>
                <DialogTitle>{editingId ? "Editar Trade" : "Registrar Novo Trade"}</DialogTitle>
                <DialogDescription>Preencha todos os campos com os detalhes da operação</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Seletor de Conta */}
                <div>
                  <Label>Conta</Label>
                  <Select value={formData.accountId} onValueChange={(value) => setFormData({ ...formData, accountId: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          Conta ${account.initialBalance} (Saldo: ${account.currentBalance.toFixed(2)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Data/Hora */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Data/Hora Entrada (Brasília)</Label>
                    <Input
                      type="datetime-local"
                      value={formData.entryDateTime}
                      onChange={(e) => setFormData({ ...formData, entryDateTime: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Data/Hora Saída (Brasília)</Label>
                    <Input
                      type="datetime-local"
                      value={formData.exitDateTime}
                      onChange={(e) => setFormData({ ...formData, exitDateTime: e.target.value })}
                    />
                  </div>
                </div>

                {/* Ativo e Tipo */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Ativo</Label>
                    <Select value={formData.asset} onValueChange={(value) => setFormData({ ...formData, asset: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GBP/USD">GBP/USD</SelectItem>
                        <SelectItem value="USD/JPY">USD/JPY</SelectItem>
                        <SelectItem value="XAU/USD">XAU/USD</SelectItem>
                        <SelectItem value="BTC/USD">BTC/USD</SelectItem>
                        <SelectItem value="AUD/CAD">AUD/CAD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Tipo</Label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as "BUY" | "SELL" })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BUY">Compra (BUY)</SelectItem>
                        <SelectItem value="SELL">Venda (SELL)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Preços */}
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Preço Entrada</Label>
                    <Input
                      type="number"
                      step="0.00001"
                      value={formData.entryPrice}
                      onChange={(e) => setFormData({ ...formData, entryPrice: e.target.value })}
                      placeholder="Ex: 155.594"
                    />
                  </div>
                  <div>
                    <Label>Preço Saída</Label>
                    <Input
                      type="number"
                      step="0.00001"
                      value={formData.exitPrice}
                      onChange={(e) => setFormData({ ...formData, exitPrice: e.target.value })}
                      placeholder="Ex: 156.216"
                    />
                  </div>
                  <div>
                    <Label>Preço Stop</Label>
                    <Input
                      type="number"
                      step="0.00001"
                      value={formData.stopPrice}
                      onChange={(e) => setFormData({ ...formData, stopPrice: e.target.value })}
                      placeholder="Ex: 155.394"
                    />
                  </div>
                </div>

                {/* Tamanho e Take Profit */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Tamanho do Contrato</Label>
                    <Input
                      type="number"
                      value={formData.contractSize}
                      onChange={(e) => setFormData({ ...formData, contractSize: e.target.value })}
                      placeholder="Ex: 16000"
                    />
                  </div>
                  <div>
                    <Label>Take Profit ($)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.takeProfit}
                      onChange={(e) => setFormData({ ...formData, takeProfit: e.target.value })}
                      placeholder="Ex: 75"
                    />
                  </div>
                </div>

                {/* Motivo e Status */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Motivo da Entrada</Label>
                    <Select value={formData.entryReason} onValueChange={(value) => setFormData({ ...formData, entryReason: value as any })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="50% OB - Execução Direta">50% OB - Execução Direta</SelectItem>
                        <SelectItem value="Primeiro Toque - Alinhamento de Fluxo">Primeiro Toque - Alinhamento de Fluxo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as any })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GANHO">Ganho</SelectItem>
                        <SelectItem value="PERDA">Perda</SelectItem>
                        <SelectItem value="CANCELADO">Cancelado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Notas */}
                <div>
                  <Label>Notas e Aprendizados</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Descreva o que aprendeu com este trade..."
                    rows={3}
                  />
                </div>

                {/* Checklist Pré-Trade Obrigatório */}
                <div className="bg-amber-50 dark:bg-amber-950/30 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                  <Label className="font-bold text-amber-900 dark:text-amber-100 mb-3 block">✓ Checklist Pré-Trade (Obrigatório)</Label>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="fibonacci"
                        checked={preTradeChecklist.fibonacciConfirmed}
                        onChange={(e) => setPreTradeChecklist({ ...preTradeChecklist, fibonacciConfirmed: e.target.checked })}
                        className="w-4 h-4 rounded"
                      />
                      <label htmlFor="fibonacci" className="text-sm text-amber-900 dark:text-amber-100">Fibonacci em H4/Diário confirmada (75%-85%)</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="ob"
                        checked={preTradeChecklist.obRefined}
                        onChange={(e) => setPreTradeChecklist({ ...preTradeChecklist, obRefined: e.target.checked })}
                        className="w-4 h-4 rounded"
                      />
                      <label htmlFor="ob" className="text-sm text-amber-900 dark:text-amber-100">Order Block refinado (H4→H2→H1)</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="choch"
                        checked={preTradeChecklist.chochValid}
                        onChange={(e) => setPreTradeChecklist({ ...preTradeChecklist, chochValid: e.target.checked })}
                        className="w-4 h-4 rounded"
                      />
                      <label htmlFor="choch" className="text-sm text-amber-900 dark:text-amber-100">CHOCH válido com liquidez confirmada</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="rr"
                        checked={preTradeChecklist.riskRewardValid}
                        onChange={(e) => setPreTradeChecklist({ ...preTradeChecklist, riskRewardValid: e.target.checked })}
                        className="w-4 h-4 rounded"
                      />
                      <label htmlFor="rr" className="text-sm text-amber-900 dark:text-amber-100">Risco:Retorno mínimo 1:3 confirmado</label>
                    </div>
                  </div>
                </div>

                {/* Upload de Imagens */}
                <div className="space-y-2">
                  <Label>Upload de Imagens</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs">Pré-Trading</Label>
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              setFormData({ ...formData, preTradeImage: event.target?.result as string });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Trading</Label>
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              setFormData({ ...formData, tradingImage: event.target?.result as string });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Pós-Trading</Label>
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              setFormData({ ...formData, postTradeImage: event.target?.result as string });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleAddTrade} 
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={!editingId && !Object.values(preTradeChecklist).every(v => v)}
                >
                  {editingId ? "Atualizar Trade" : "Registrar Trade"}
                </Button>
                {!editingId && !Object.values(preTradeChecklist).every(v => v) && (
                  <p className="text-xs text-red-600 dark:text-red-400 text-center">Complete o checklist pré-trade para registrar</p>
                )}
              </div>
            </DialogContent>
          </Dialog>

          {/* Filtros */}
          <div className="flex flex-wrap gap-2">
            <Select value={filterAsset} onValueChange={setFilterAsset}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Ativos</SelectItem>
                <SelectItem value="GBP/USD">GBP/USD</SelectItem>
                <SelectItem value="USD/JPY">USD/JPY</SelectItem>
                <SelectItem value="XAU/USD">XAU/USD</SelectItem>
                <SelectItem value="BTC/USD">BTC/USD</SelectItem>
                <SelectItem value="AUD/CAD">AUD/CAD</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Status</SelectItem>
                <SelectItem value="GANHO">Ganho</SelectItem>
                <SelectItem value="PERDA">Perda</SelectItem>
                <SelectItem value="CANCELADO">Cancelado</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterSession} onValueChange={setFilterSession}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Sessões</SelectItem>
                <SelectItem value="Tóquio">Tóquio</SelectItem>
                <SelectItem value="Londres">Londres</SelectItem>
                <SelectItem value="Nova York">Nova York</SelectItem>
                <SelectItem value="Sobreposição">Sobreposição</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant={filterFavorites ? "default" : "outline"}
              onClick={() => setFilterFavorites(!filterFavorites)}
              className="gap-2"
            >
              <Star className="w-4 h-4" />
              Favoritos
            </Button>

            <Button variant="outline" onClick={() => exportAsJSON()} className="gap-2">
              <Download className="w-4 h-4" />
              JSON
            </Button>

            <Button variant="outline" onClick={() => exportAsCSV()} className="gap-2">
              <Download className="w-4 h-4" />
              CSV
            </Button>
          </div>

          {/* Estatísticas */}
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground">Total Trades</p>
                <p className="text-lg font-bold text-foreground">{stats.totalTrades}</p>
              </div>
              <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground">Taxa Acerto</p>
                <p className="text-lg font-bold text-foreground">{Number(stats.winRate).toFixed(1)}%</p>
              </div>
              <div className="bg-secondary/50 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground">Lucro Total</p>
                <p className={`text-lg font-bold ${Number(stats.totalProfit) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${Number(stats.totalProfit).toFixed(2)}
                </p>
              </div>

            </div>
          )}

          {/* Histórico de Trades */}
          <div className="space-y-3">
            {filteredTrades.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Nenhum trade registrado com os filtros selecionados</p>
              </div>
            ) : (
              filteredTrades.map((trade) => (
                <div key={trade.id} className="bg-secondary/50 p-4 rounded-lg border border-border space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-bold text-foreground">{trade.asset}</p>
                        <Badge variant={trade.type === "BUY" ? "default" : "secondary"}>{trade.type}</Badge>
                        <Badge className={trade.status === "GANHO" ? "bg-green-600" : trade.status === "PERDA" ? "bg-red-600" : "bg-gray-600"}>
                          {trade.status}
                        </Badge>
                        {trade.isFavorite && <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {new Date(trade.entryDateTime).toLocaleString("pt-BR")} → {new Date(trade.exitDateTime).toLocaleString("pt-BR")}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Entrada: {Number(trade.entryPrice).toFixed(5)} | Saída: {Number(trade.exitPrice).toFixed(5)} | Stop: {Number(trade.stopPrice).toFixed(5)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Sessão: {trade.session} | Duração: {calculateDuration(trade.entryDateTime, trade.exitDateTime)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        P&L: ${Number(trade.profitLoss).toFixed(2)} ({Number(trade.profitLossPercent).toFixed(2)}%) | Pips: {trade.pipsGained}
                      </p>
                      {trade.notes && <p className="text-xs text-foreground/70 mt-2 italic">{trade.notes}</p>}
                    </div>
                    <div className="flex gap-2">
                      {(trade.preTradeImage || trade.tradingImage || trade.postTradeImage) && (
                        <div className="flex gap-1">
                          {trade.preTradeImage && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedImage({ url: trade.preTradeImage!, title: "Pré-Trading" })}
                            >
                              Pré
                            </Button>
                          )}
                          {trade.tradingImage && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedImage({ url: trade.tradingImage!, title: "Trading" })}
                            >
                              Trading
                            </Button>
                          )}
                          {trade.postTradeImage && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedImage({ url: trade.postTradeImage!, title: "Pós-Trading" })}
                            >
                              Pós
                            </Button>
                          )}
                        </div>
                      )}
                      <Button variant="outline" size="sm" onClick={() => handleEditTrade(trade)}>
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleFavorite(trade.id)}
                        className={trade.isFavorite ? "bg-yellow-100" : ""}
                      >
                        <Star className={`w-4 h-4 ${trade.isFavorite ? "fill-yellow-500 text-yellow-500" : ""}`} />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => deleteTrade(trade.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Modal de Visualizacao de Imagens com Zoom e Desenho */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setSelectedImage(null)}>
          <div className="bg-white rounded-lg max-w-5xl max-h-[90vh] overflow-auto flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-white border-b p-4 flex justify-between items-center">
              <h3 className="font-semibold text-lg">{selectedImage.title}</h3>
              <div className="flex gap-2 items-center">
                <button onClick={() => setZoom(Math.max(0.5, zoom - 0.2))} className="p-2 hover:bg-gray-100 rounded" title="Zoom Out">
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="text-sm font-medium w-12 text-center">{Math.round(zoom * 100)}%</span>
                <button onClick={() => setZoom(Math.min(3, zoom + 0.2))} className="p-2 hover:bg-gray-100 rounded" title="Zoom In">
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button onClick={() => setShowDrawTools(!showDrawTools)} className="p-2 hover:bg-gray-100 rounded" title="Ferramentas de Desenho">
                  <Pen className="w-4 h-4" />
                </button>
                <button onClick={() => setSelectedImage(null)} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
              </div>
            </div>
            {showDrawTools && (
              <div className="bg-gray-100 border-b p-3 flex gap-3 items-center flex-wrap">
                <label className="flex items-center gap-2">
                  <span className="text-sm">Cor:</span>
                  <input type="color" value={drawColor} onChange={(e) => setDrawColor(e.target.value)} className="w-8 h-8 cursor-pointer" />
                </label>
                <label className="flex items-center gap-2">
                  <span className="text-sm">Tamanho:</span>
                  <input type="range" min="1" max="20" value={drawSize} onChange={(e) => setDrawSize(Number(e.target.value))} className="w-24" />
                  <span className="text-xs text-gray-600">{drawSize}px</span>
                </label>
                <span className="text-xs text-gray-600">Clique e arraste para desenhar</span>
              </div>
            )}
            <div className="p-4 flex-1 overflow-auto flex items-center justify-center bg-gray-50">
              <div style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}>
                <canvas
                  ref={canvasRef}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  className="border border-gray-300 cursor-crosshair bg-white"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
