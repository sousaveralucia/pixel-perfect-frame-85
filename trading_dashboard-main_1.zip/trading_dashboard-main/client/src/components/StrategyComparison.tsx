import { useMemo, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { TrendingUp } from "lucide-react";
import { Trade } from "@/hooks/useTradeJournal";
import { useAccountManager } from "@/hooks/useAccountManager";

interface StrategyComparison {
  strategy: string;
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  totalProfit: number;
  avgProfit: number;
  largestWin: number;
  largestLoss: number;
  profitFactor: number;
}

interface StrategyComparisonProps {
  trades: Trade[];
}

export default function StrategyComparison({ trades }: StrategyComparisonProps) {
  const { accounts, activeAccountId, switchAccount } = useAccountManager();
  const [filterAccount, setFilterAccount] = useState<string>(activeAccountId);
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const allAssets = ["EUR/USD", "USDJPY", "XAUUSD", "NASDAQ", "BTC USD"];

  // Filtrar trades pela conta selecionada
  const accountTrades = trades.filter((t) => t.accountId === filterAccount);

  const comparison = useMemo(() => {
    const strategies = {
      "50% OB - Execução Direta": [] as Trade[],
      "Primeiro Toque - Alinhamento de Fluxo": [] as Trade[],
    };

    // Filtrar trades por conta e ativo
    let filteredTrades = accountTrades;
    if (filterAsset !== "all") {
      filteredTrades = filteredTrades.filter((t) => t.asset === filterAsset);
    }

    filteredTrades.forEach((trade) => {
      if (strategies[trade.entryReason as keyof typeof strategies]) {
        strategies[trade.entryReason as keyof typeof strategies].push(trade);
      }
    });

    const calculateStats = (strategyTrades: Trade[]): StrategyComparison => {
      if (strategyTrades.length === 0) {
        return {
          strategy: "",
          totalTrades: 0,
          wins: 0,
          losses: 0,
          winRate: 0,
          totalProfit: 0,
          avgProfit: 0,
          largestWin: 0,
          largestLoss: 0,
          profitFactor: 0,
        };
      }

      const wins = strategyTrades.filter((t) => t.status === "GANHO").length;
      const losses = strategyTrades.filter((t) => t.status === "PERDA").length;
      const totalProfit = strategyTrades.reduce((sum, t) => sum + Number(t.profitLoss), 0);
      const winTrades = strategyTrades.filter((t) => t.status === "GANHO");
      const lossTrades = strategyTrades.filter((t) => t.status === "PERDA");
      const largestWin = winTrades.length > 0 ? Math.max(...winTrades.map((t) => Number(t.profitLoss))) : 0;
      const largestLoss = lossTrades.length > 0 ? Math.min(...lossTrades.map((t) => Number(t.profitLoss))) : 0;
      const profitFactor = losses > 0 ? Math.abs(totalProfit / (largestLoss * losses)) : totalProfit > 0 ? 999 : 0;

      return {
        strategy: "",
        totalTrades: strategyTrades.length,
        wins,
        losses,
        winRate: (wins / strategyTrades.length) * 100,
        totalProfit,
        avgProfit: totalProfit / strategyTrades.length,
        largestWin,
        largestLoss,
        profitFactor,
      };
    };

    return {
      "50% OB": { ...calculateStats(strategies["50% OB - Execução Direta"]), strategy: "50% OB - Execução Direta" },
      "Primeiro Toque": { ...calculateStats(strategies["Primeiro Toque - Alinhamento de Fluxo"]), strategy: "Primeiro Toque - Alinhamento de Fluxo" },
    };
  }, [accountTrades, filterAsset, filterAccount]);

  const chartData = [
    {
      name: "50% OB",
      "Taxa de Acerto": Number(comparison["50% OB"].winRate.toFixed(1)),
      "Lucro Total": Number(comparison["50% OB"].totalProfit.toFixed(2)),
    },
    {
      name: "Primeiro Toque",
      "Taxa de Acerto": Number(comparison["Primeiro Toque"].winRate.toFixed(1)),
      "Lucro Total": Number(comparison["Primeiro Toque"].totalProfit.toFixed(2)),
    },
  ];

  const pieData = [
    { name: "50% OB", value: comparison["50% OB"].totalTrades, fill: "#3b82f6" },
    { name: "Primeiro Toque", value: comparison["Primeiro Toque"].totalTrades, fill: "#10b981" },
  ];

  const COLORS = ["#3b82f6", "#10b981"];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-secondary/50 rounded-lg border border-border">
        <div>
          <Label className="text-sm font-semibold mb-2 block">Filtrar por Conta</Label>
          <Select value={filterAccount} onValueChange={setFilterAccount}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {accounts.map((account) => (
                <SelectItem key={account.id} value={account.id}>
                  Conta ${account.initialBalance} (Saldo: ${account.currentBalance.toFixed(2)})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-semibold mb-2 block">Filtrar por Ativo</Label>
          <Select value={filterAsset} onValueChange={setFilterAsset}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Ativos</SelectItem>
              {allAssets.map((asset) => (
                <SelectItem key={asset} value={asset}>
                  {asset}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Comparação de Estratégias
          </CardTitle>
          <CardDescription>Análise de performance entre "50% OB" e "Primeiro Toque"</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tabela Comparativa */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-3 font-semibold">Métrica</th>
                  <th className="text-center py-2 px-3 font-semibold">50% OB</th>
                  <th className="text-center py-2 px-3 font-semibold">Primeiro Toque</th>
                  <th className="text-center py-2 px-3 font-semibold">Diferença</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Total de Trades</td>
                  <td className="text-center py-2 px-3 font-medium">{comparison["50% OB"].totalTrades}</td>
                  <td className="text-center py-2 px-3 font-medium">{comparison["Primeiro Toque"].totalTrades}</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {comparison["50% OB"].totalTrades - comparison["Primeiro Toque"].totalTrades > 0 ? "+" : ""}
                    {comparison["50% OB"].totalTrades - comparison["Primeiro Toque"].totalTrades}
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Ganhos</td>
                  <td className="text-center py-2 px-3 font-medium text-green-600">{comparison["50% OB"].wins}</td>
                  <td className="text-center py-2 px-3 font-medium text-green-600">{comparison["Primeiro Toque"].wins}</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {comparison["50% OB"].wins - comparison["Primeiro Toque"].wins > 0 ? "+" : ""}
                    {comparison["50% OB"].wins - comparison["Primeiro Toque"].wins}
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Perdas</td>
                  <td className="text-center py-2 px-3 font-medium text-red-600">{comparison["50% OB"].losses}</td>
                  <td className="text-center py-2 px-3 font-medium text-red-600">{comparison["Primeiro Toque"].losses}</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {comparison["50% OB"].losses - comparison["Primeiro Toque"].losses > 0 ? "+" : ""}
                    {comparison["50% OB"].losses - comparison["Primeiro Toque"].losses}
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Taxa de Acerto</td>
                  <td className="text-center py-2 px-3 font-medium">{comparison["50% OB"].winRate.toFixed(1)}%</td>
                  <td className="text-center py-2 px-3 font-medium">{comparison["Primeiro Toque"].winRate.toFixed(1)}%</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {(comparison["50% OB"].winRate - comparison["Primeiro Toque"].winRate > 0 ? "+" : "")}
                    {(comparison["50% OB"].winRate - comparison["Primeiro Toque"].winRate).toFixed(1)}%
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Lucro Total</td>
                  <td className={`text-center py-2 px-3 font-medium ${comparison["50% OB"].totalProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${comparison["50% OB"].totalProfit.toFixed(2)}
                  </td>
                  <td className={`text-center py-2 px-3 font-medium ${comparison["Primeiro Toque"].totalProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${comparison["Primeiro Toque"].totalProfit.toFixed(2)}
                  </td>
                  <td className={`text-center py-2 px-3 text-xs ${comparison["50% OB"].totalProfit - comparison["Primeiro Toque"].totalProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {comparison["50% OB"].totalProfit - comparison["Primeiro Toque"].totalProfit > 0 ? "+" : ""}
                    ${(comparison["50% OB"].totalProfit - comparison["Primeiro Toque"].totalProfit).toFixed(2)}
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Lucro Médio</td>
                  <td className={`text-center py-2 px-3 font-medium ${comparison["50% OB"].avgProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${comparison["50% OB"].avgProfit.toFixed(2)}
                  </td>
                  <td className={`text-center py-2 px-3 font-medium ${comparison["Primeiro Toque"].avgProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${comparison["Primeiro Toque"].avgProfit.toFixed(2)}
                  </td>
                  <td className={`text-center py-2 px-3 text-xs ${comparison["50% OB"].avgProfit - comparison["Primeiro Toque"].avgProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {comparison["50% OB"].avgProfit - comparison["Primeiro Toque"].avgProfit > 0 ? "+" : ""}
                    ${(comparison["50% OB"].avgProfit - comparison["Primeiro Toque"].avgProfit).toFixed(2)}
                  </td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="py-2 px-3">Maior Ganho</td>
                  <td className="text-center py-2 px-3 font-medium text-green-600">${comparison["50% OB"].largestWin.toFixed(2)}</td>
                  <td className="text-center py-2 px-3 font-medium text-green-600">${comparison["Primeiro Toque"].largestWin.toFixed(2)}</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {comparison["50% OB"].largestWin - comparison["Primeiro Toque"].largestWin > 0 ? "+" : ""}
                    ${(comparison["50% OB"].largestWin - comparison["Primeiro Toque"].largestWin).toFixed(2)}
                  </td>
                </tr>
                <tr className="hover:bg-secondary/30">
                  <td className="py-2 px-3">Maior Perda</td>
                  <td className="text-center py-2 px-3 font-medium text-red-600">${comparison["50% OB"].largestLoss.toFixed(2)}</td>
                  <td className="text-center py-2 px-3 font-medium text-red-600">${comparison["Primeiro Toque"].largestLoss.toFixed(2)}</td>
                  <td className="text-center py-2 px-3 text-xs text-muted-foreground">
                    {comparison["50% OB"].largestLoss - comparison["Primeiro Toque"].largestLoss > 0 ? "+" : ""}
                    ${(comparison["50% OB"].largestLoss - comparison["Primeiro Toque"].largestLoss).toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Gráfico de Comparação */}
          {(comparison["50% OB"].totalTrades > 0 || comparison["Primeiro Toque"].totalTrades > 0) && (
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Gráficos Comparativos</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="Taxa de Acerto" fill="#3b82f6" />
                  <Bar yAxisId="right" dataKey="Lucro Total" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>

              {/* Distribuição de Trades */}
              <div className="flex justify-center">
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={pieData.filter((item) => item.value > 0)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Recomendação */}
          {comparison["50% OB"].totalTrades > 0 && comparison["Primeiro Toque"].totalTrades > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm font-semibold text-blue-900 mb-2">💡 Recomendação</p>
              <p className="text-sm text-blue-900">
                {comparison["50% OB"].winRate > comparison["Primeiro Toque"].winRate
                  ? `A estratégia "50% OB - Execução Direta" tem uma taxa de acerto ${(comparison["50% OB"].winRate - comparison["Primeiro Toque"].winRate).toFixed(1)}% superior. Considere aumentar o foco nesta estratégia.`
                  : `A estratégia "Primeiro Toque - Alinhamento de Fluxo" tem uma taxa de acerto ${(comparison["Primeiro Toque"].winRate - comparison["50% OB"].winRate).toFixed(1)}% superior. Considere aumentar o foco nesta estratégia.`}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
