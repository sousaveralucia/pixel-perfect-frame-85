import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText } from "lucide-react";
import { useTradeJournalUnified, TradeWithChecklist } from "@/hooks/useTradeJournalUnified";
import { useAccountManager } from "@/hooks/useAccountManager";

export default function ReportExport() {
  const { activeAccountId } = useAccountManager();
  const { trades } = useTradeJournalUnified(activeAccountId);
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePDFReport = async () => {
    setIsGenerating(true);
    try {
      // Importar dinamicamente a biblioteca jsPDF
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF();

      // Título
      doc.setFontSize(20);
      doc.text("Relatório de Trades", 20, 20);

      // Data de geração
      doc.setFontSize(10);
      doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}`, 20, 30);

      // Estatísticas gerais
      const totalTrades = trades.length;
      const wins = trades.filter((t) => t.result === "WIN").length;
      const losses = trades.filter((t) => t.result === "LOSS").length;
      const totalProfit = 0; // Será calculado a partir dos dados disponíveis
      const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;

      doc.setFontSize(12);
      doc.text("Resumo Executivo", 20, 45);

      doc.setFontSize(10);
      const summaryY = 55;
      doc.text(`Total de Trades: ${totalTrades}`, 20, summaryY);
      doc.text(`Ganhos: ${wins}`, 20, summaryY + 7);
      doc.text(`Perdas: ${losses}`, 20, summaryY + 14);
      doc.text(`Taxa de Acerto: ${winRate.toFixed(1)}%`, 20, summaryY + 21);
      doc.text(`Lucro Total: $${totalProfit.toFixed(2)}`, 20, summaryY + 28);

      // Tabela de trades
      let yPosition = summaryY + 45;

      doc.setFontSize(12);
      doc.text("Histórico de Trades", 20, yPosition);
      yPosition += 10;

      // Cabeçalho da tabela
      doc.setFontSize(9);
      doc.setTextColor(255, 255, 255);
      doc.setFillColor(59, 130, 246); // Azul
      doc.rect(20, yPosition, 170, 6, "F");
      doc.text("Data", 22, yPosition + 4);
      doc.text("Ativo", 45, yPosition + 4);
      doc.text("Tipo", 70, yPosition + 4);
      doc.text("Status", 85, yPosition + 4);
      doc.text("P&L", 110, yPosition + 4);
      doc.text("Sessão", 140, yPosition + 4);

      yPosition += 8;
      doc.setTextColor(0, 0, 0);

      // Dados da tabela
      trades.slice(0, 20).forEach((trade, index) => {
        if (yPosition > 270) {
          doc.addPage();
          yPosition = 20;
        }

        const bgColor = index % 2 === 0 ? [245, 245, 245] : [255, 255, 255];
        doc.setFillColor(bgColor[0], bgColor[1], bgColor[2]);
        doc.rect(20, yPosition, 170, 5, "F");

        const date = trade.date;
        const profitLossColor = trade.result === 'WIN' ? [34, 197, 94] : [239, 68, 68]; // Verde ou Vermelho
        doc.setTextColor(profitLossColor[0], profitLossColor[1], profitLossColor[2]);

        doc.setFontSize(8);
        doc.text(date, 22, yPosition + 3);
        doc.setTextColor(0, 0, 0);
        doc.text(trade.asset, 45, yPosition + 3);
        doc.text('-', 70, yPosition + 3);
        doc.text(trade.result === 'WIN' ? 'Vitória' : 'Derrota', 85, yPosition + 3);
        doc.setTextColor(profitLossColor[0], profitLossColor[1], profitLossColor[2]);
        doc.text('-', 110, yPosition + 3);
        doc.setTextColor(0, 0, 0);
        doc.text(trade.session || '-', 140, yPosition + 3);

        yPosition += 6;
      });

      // Rodapé
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text("Relatório confidencial - Apenas para uso pessoal", 20, doc.internal.pageSize.getHeight() - 10);

      // Salvar PDF
      doc.save(`trading-report-${new Date().toISOString().split("T")[0]}.pdf`);
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      alert("Erro ao gerar relatório PDF");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Exportar Relatório
          </CardTitle>
          <CardDescription>Gere um relatório em PDF com todos os seus trades</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {trades.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">Nenhum trade registrado ainda</p>
              <p className="text-sm text-muted-foreground">Registre seus trades no Diário para gerar um relatório</p>
            </div>
          ) : (
            <>
              <div className="bg-secondary/50 p-4 rounded-lg space-y-2">
                <p className="text-sm font-semibold text-foreground">Resumo do Relatório</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div>
                    <p className="text-xs text-muted-foreground">Total de Trades</p>
                    <p className="text-lg font-bold text-foreground">{trades.length}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Ganhos</p>
                    <p className="text-lg font-bold text-green-600">{trades.filter((t) => t.result === "WIN").length}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Perdas</p>
                    <p className="text-lg font-bold text-red-600">{trades.filter((t) => t.result === "LOSS").length}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Lucro Total</p>
                    <p className="text-lg font-bold text-foreground">-</p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900">
                  📄 O relatório incluirá um resumo executivo e os últimos 20 trades com suas informações principais.
                </p>
              </div>

              <Button
                onClick={generatePDFReport}
                disabled={isGenerating}
                className="w-full bg-primary hover:bg-primary/90 gap-2"
              >
                <Download className="w-4 h-4" />
                {isGenerating ? "Gerando..." : "Gerar Relatório em PDF"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
