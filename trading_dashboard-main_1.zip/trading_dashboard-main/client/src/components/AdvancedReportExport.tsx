import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Calendar } from "lucide-react";
import { Trade } from "@/hooks/useTradeJournal";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useAccountManager } from "@/hooks/useAccountManager";

interface AdvancedReportExportProps {
  trades: Trade[];
  accountName: string;
  accountBalance: number;
}

export default function AdvancedReportExport({ trades, accountName, accountBalance }: AdvancedReportExportProps) {
  const { accounts, activeAccountId, switchAccount } = useAccountManager();
  const [filterAccount, setFilterAccount] = useState<string>(activeAccountId);
  const [filterAsset, setFilterAsset] = useState<string>("all");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const allAssets = ["EUR/USD", "USDJPY", "XAUUSD", "NASDAQ", "BTC USD"];
  
  // Filtrar trades pela conta selecionada
  const accountFilteredTrades = trades.filter((t) => t.accountId === filterAccount);

  const getFilteredTrades = () => {
    return accountFilteredTrades.filter((trade) => {
      const tradeDate = new Date(trade.entryDateTime);
      const start = startDate ? new Date(startDate) : new Date(0);
      const end = endDate ? new Date(endDate) : new Date();
      const assetMatch = filterAsset === "all" || trade.asset === filterAsset;

      return tradeDate >= start && tradeDate <= end && assetMatch;
    });
  };

  const filteredTrades = getFilteredTrades();

  const calculateStats = (tradesData: Trade[]) => {
    const total = tradesData.length;
    const wins = tradesData.filter((t) => t.status === "GANHO").length;
    const losses = tradesData.filter((t) => t.status === "PERDA").length;
    const totalProfit = tradesData.reduce((sum, t) => sum + Number(t.profitLoss), 0);
    const winRate = total > 0 ? (wins / total) * 100 : 0;

    return { total, wins, losses, totalProfit, winRate };
  };

  const stats = calculateStats(filteredTrades);

  const generatePDFReport = async () => {
    setIsGenerating(true);
    try {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF();

      // Título
      doc.setFontSize(20);
      doc.text("Relatório de Trades", 20, 20);

      // Informações da conta
      doc.setFontSize(10);
      doc.text(`Conta: ${accountName}`, 20, 30);
      doc.text(`Saldo: $${accountBalance.toFixed(2)}`, 20, 37);
      doc.text(`Período: ${startDate || "Início"} até ${endDate || "Hoje"}`, 20, 44);
      doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}`, 20, 51);

      // Estatísticas
      doc.setFontSize(12);
      doc.text("Resumo Executivo", 20, 65);

      doc.setFontSize(10);
      const summaryY = 75;
      doc.text(`Total de Trades: ${stats.total}`, 20, summaryY);
      doc.text(`Ganhos: ${stats.wins}`, 20, summaryY + 7);
      doc.text(`Perdas: ${stats.losses}`, 20, summaryY + 14);
      doc.text(`Taxa de Acerto: ${stats.winRate.toFixed(1)}%`, 20, summaryY + 21);
      doc.text(`Lucro Total: $${stats.totalProfit.toFixed(2)}`, 20, summaryY + 28);

      // Tabela de trades
      let yPosition = summaryY + 45;

      doc.setFontSize(12);
      doc.text("Histórico de Trades", 20, yPosition);
      yPosition += 10;

      // Cabeçalho da tabela
      doc.setFontSize(9);
      doc.setTextColor(255, 255, 255);
      doc.setFillColor(59, 130, 246);
      doc.rect(20, yPosition, 170, 6, "F");
      doc.text("Data", 22, yPosition + 4);
      doc.text("Ativo", 45, yPosition + 4);
      doc.text("Tipo", 70, yPosition + 4);
      doc.text("Status", 85, yPosition + 4);
      doc.text("P&L", 110, yPosition + 4);
      doc.text("Sessão", 140, yPosition + 4);

      yPosition += 8;
      doc.setTextColor(0, 0, 0);

      // Dados da tabela
      filteredTrades.slice(0, 25).forEach((trade, index) => {
        if (yPosition > 270) {
          doc.addPage();
          yPosition = 20;
        }

        const bgColor = index % 2 === 0 ? [245, 245, 245] : [255, 255, 255];
        doc.setFillColor(bgColor[0], bgColor[1], bgColor[2]);
        doc.rect(20, yPosition, 170, 5, "F");

        const date = new Date(trade.entryDateTime).toLocaleDateString("pt-BR");
        const profitLossColor = Number(trade.profitLoss) >= 0 ? [34, 197, 94] : [239, 68, 68];
        doc.setTextColor(profitLossColor[0], profitLossColor[1], profitLossColor[2]);

        doc.setFontSize(8);
        doc.text(date, 22, yPosition + 3);
        doc.setTextColor(0, 0, 0);
        doc.text(trade.asset, 45, yPosition + 3);
        doc.text(trade.type, 70, yPosition + 3);
        doc.text(trade.status, 85, yPosition + 3);
        doc.setTextColor(profitLossColor[0], profitLossColor[1], profitLossColor[2]);
        doc.text(`$${Number(trade.profitLoss).toFixed(2)}`, 110, yPosition + 3);
        doc.setTextColor(0, 0, 0);
        doc.text(trade.session, 140, yPosition + 3);

        yPosition += 6;
      });

      // Rodapé
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text("Relatório confidencial - Apenas para uso pessoal", 20, doc.internal.pageSize.getHeight() - 10);

      // Salvar PDF
      const fileName = `trading-report-${accountName.replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.pdf`;
      doc.save(fileName);
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      alert("Erro ao gerar relatório PDF");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Filtros */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-secondary/50 rounded-lg border border-border">
        <div>
          <Label className="text-sm font-semibold mb-2 block">Filtrar por Conta</Label>
          <Select value={filterAccount} onValueChange={setFilterAccount}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {accounts.map((account) => (
                <SelectItem key={account.id} value={account.id}>
                  Conta ${account.initialBalance} (Saldo: ${account.currentBalance.toFixed(2)})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-semibold mb-2 block">Filtrar por Ativo</Label>
          <Select value={filterAsset} onValueChange={setFilterAsset}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Ativos</SelectItem>
              {allAssets.map((asset) => (
                <SelectItem key={asset} value={asset}>
                  {asset}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Relatório Customizado
          </CardTitle>
          <CardDescription>Gere relatórios com período customizado</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Informações da Conta */}
          <div className="bg-secondary/50 p-4 rounded-lg border border-border">
            <p className="text-sm font-semibold text-foreground">Conta Selecionada</p>
            <p className="text-lg font-bold text-primary">{accountName}</p>
            <p className="text-sm text-muted-foreground mt-1">Saldo: ${accountBalance.toFixed(2)}</p>
          </div>

          {/* Filtro de Datas */}
          <div className="space-y-3">
            <p className="font-semibold text-foreground flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Período do Relatório
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Data Inicial</label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Data Final</label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
          </div>

          {/* Resumo do Relatório */}
          {filteredTrades.length > 0 ? (
            <>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm font-semibold text-blue-900 mb-3">Resumo do Período</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div>
                    <p className="text-xs text-blue-800">Trades</p>
                    <p className="text-lg font-bold text-blue-900">{stats.total}</p>
                  </div>
                  <div>
                    <p className="text-xs text-blue-800">Ganhos</p>
                    <p className="text-lg font-bold text-green-600">{stats.wins}</p>
                  </div>
                  <div>
                    <p className="text-xs text-blue-800">Perdas</p>
                    <p className="text-lg font-bold text-red-600">{stats.losses}</p>
                  </div>
                  <div>
                    <p className="text-xs text-blue-800">Taxa</p>
                    <p className="text-lg font-bold text-blue-900">{stats.winRate.toFixed(1)}%</p>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-blue-200">
                  <p className="text-sm text-blue-800">
                    Lucro Total: <span className={`font-bold ${stats.totalProfit >= 0 ? "text-green-600" : "text-red-600"}`}>${stats.totalProfit.toFixed(2)}</span>
                  </p>
                </div>
              </div>

              <Button
                onClick={generatePDFReport}
                disabled={isGenerating}
                className="w-full bg-primary hover:bg-primary/90 gap-2"
              >
                <Download className="w-4 h-4" />
                {isGenerating ? "Gerando..." : "Gerar Relatório em PDF"}
              </Button>
            </>
          ) : (
            <div className="text-center py-8 bg-secondary/50 rounded-lg border border-border">
              <p className="text-muted-foreground">Nenhum trade encontrado para este período</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
