import { useAuth } from "@/_core/hooks/useAuth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { CheckCircle2, AlertCircle, TrendingUp, Target, Clock, Zap } from "lucide-react";
import RiskCalculator from "@/components/RiskCalculator";
import EconomicCalendar from "@/components/EconomicCalendar";
import NewsAlerts from "@/components/NewsAlerts";
import TradeJournal from "@/components/TradeJournal";
import TradeJournalEnhanced from "@/components/TradeJournalEnhanced";
import PerformanceDashboard from "@/components/PerformanceDashboard";
import StrategyComparison from "@/components/StrategyComparison";
import StrategyComparisonEnhanced from "@/components/StrategyComparisonEnhanced";
import ReportExport from "@/components/ReportExport";
import ReportExportEnhanced from "@/components/ReportExportEnhanced";
import AccountSelector from "@/components/AccountSelector";
import WinRateAnalysis from "@/components/WinRateAnalysis";
import AdvancedReportExport from "@/components/AdvancedReportExport";
import AnalysisHistory from "@/components/AnalysisHistory";
import DailyValidation from "@/components/DailyValidation";
import AssetPerformanceAnalysis from "@/components/AssetPerformanceAnalysis";
import DailyValidationHistory from "@/components/DailyValidationHistory";
import { TradingCalendar } from "@/components/TradingCalendar";
import { useTradeJournal } from "@/hooks/useTradeJournal";
import { useTradeJournalUnified, TradeWithChecklist } from "@/hooks/useTradeJournalUnified";
import { useAccountManager } from "@/hooks/useAccountManager";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useTheme } from "@/contexts/ThemeContext";
import { Moon, Sun } from "lucide-react";
import { useInitializeUserAccounts } from "@/hooks/useInitializeUserAccounts";

/**
 * Trading Dashboard - Plano Operacional Completo
 * Design: Minimalismo Corporativo com foco em dados
 * Tipografia: Roboto (Bold para títulos, Regular para corpo)
 * Cores: Azul corporativo (#0066cc), Verde (#22c55e), Vermelho (#ef4444)
 */

function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleTheme}
      className="rounded-full"
      title={`Alternar para tema ${theme === 'light' ? 'escuro' : 'claro'}`}
    >
      {theme === 'light' ? (
        <Moon className="h-4 w-4" />
      ) : (
        <Sun className="h-4 w-4" />
      )}
    </Button>
  );
}

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  // Inicializar contas padrão para novos usuários
  useInitializeUserAccounts();

  const { trades } = useTradeJournal();
  const { getActiveAccount, accounts, activeAccountId } = useAccountManager();
  const { trades: tradesUnified } = useTradeJournalUnified(activeAccountId);
  const activeAccount = accounts.length > 0 ? getActiveAccount() : { name: "Carregando...", currentBalance: 0 };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background sticky top-0 z-10">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Trading Dashboard</h1>
              <p className="text-sm text-muted-foreground mt-1">Plano Operacional - HackTrading Plan</p>
            </div>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Badge className="bg-primary text-primary-foreground">Ativo</Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <Tabs defaultValue="calendario-trading" className="w-full">
          <TabsList className="flex w-full mb-8 overflow-x-auto gap-1 bg-secondary/30 p-1 rounded-lg border border-border">
            <TabsTrigger value="calendario-trading" className="text-xs whitespace-nowrap">Calendário</TabsTrigger>
            <TabsTrigger value="contas" className="text-xs whitespace-nowrap">Contas</TabsTrigger>
            <TabsTrigger value="autoconhecimento" className="text-xs whitespace-nowrap">Autoconhecimento</TabsTrigger>
            <TabsTrigger value="ativos" className="text-xs whitespace-nowrap">Ativos</TabsTrigger>
            <TabsTrigger value="estrategia" className="text-xs whitespace-nowrap">Estratégia</TabsTrigger>
            <TabsTrigger value="gestao" className="text-xs whitespace-nowrap">Gestão</TabsTrigger>
            <TabsTrigger value="rotina" className="text-xs whitespace-nowrap">Rotina</TabsTrigger>
            <TabsTrigger value="alertas" className="text-xs whitespace-nowrap">Alertas</TabsTrigger>
            <TabsTrigger value="analises" className="text-xs whitespace-nowrap">Análises</TabsTrigger>
            <TabsTrigger value="calculadora" className="text-xs whitespace-nowrap">Calculadora</TabsTrigger>
            <TabsTrigger value="diario" className="text-xs whitespace-nowrap">Diário</TabsTrigger>
            <TabsTrigger value="calendario" className="text-xs whitespace-nowrap">Calendário Econômico</TabsTrigger>
            <TabsTrigger value="insights" className="text-xs whitespace-nowrap">Insights</TabsTrigger>
            <TabsTrigger value="comparacao-enhanced" className="text-xs whitespace-nowrap">Comparação</TabsTrigger>
            <TabsTrigger value="relatorio-enhanced" className="text-xs whitespace-nowrap">Relatório</TabsTrigger>
            <TabsTrigger value="validacao" className="text-xs whitespace-nowrap">Validação</TabsTrigger>
          </TabsList>

          {/* Tab: Calendário Trading */}
          <TabsContent value="calendario-trading" className="space-y-6">
            <TradingCalendar activeAccountId={activeAccountId} />
          </TabsContent>

          {/* Tab: Autoconhecimento */}
          <TabsContent value="autoconhecimento" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                  Autoconhecimento
                </CardTitle>
                <CardDescription>Entenda seus objetivos, motivações e características como trader</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-bold text-foreground mb-3">Por que você faz trade? Quais são seus objetivos?</h3>
                  <p className="text-foreground/80">
                    O principal objetivo é <strong>viver do mercado financeiro e sair do regime CLT</strong>, buscando uma melhor qualidade de vida, mais liberdade e remuneração justa. Um objetivo pessoal significativo é <strong>resolver problemas dentários</strong> decorrentes de um acidente.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-bold text-foreground mb-3">Regime de Operação</h3>
                  <Badge className="bg-blue-100 text-blue-800">Meio Período</Badge>
                  <p className="text-sm text-foreground/80 mt-2">Operações nas horas vagas disponíveis do trabalho CLT</p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-bold text-foreground mb-3">Motivação Principal</h3>
                  <p className="text-foreground/80">
                    A esperança de poder <strong>mudar de vida</strong> para si e para a família é a principal motivação e fonte de satisfação no trading.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-bold text-foreground mb-3">5 Pontos Fortes</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    {[
                      { title: "Persistência", desc: "Capacidade de continuar buscando o objetivo" },
                      { title: "Força de vontade", desc: "Determinação para alcançar o sucesso" },
                      { title: "Tempo para estudar", desc: "Dedicação extra ao aprendizado" },
                      { title: "Foco no objetivo", desc: "Clareza sobre viver do mercado" },
                      { title: "Paciência", desc: "Esperar pelas melhores oportunidades" },
                    ].map((point, idx) => (
                      <Card key={idx} className="bg-green-50 border-green-200">
                        <CardContent className="pt-4">
                          <p className="font-bold text-green-900">{point.title}</p>
                          <p className="text-sm text-green-800">{point.desc}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-bold text-foreground mb-3">5 Pontos Fracos e Estratégias de Contorno</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    {[
                      { title: "Emocional", strategy: "Aprimorar controle emocional através de mindfulness e revisão pós-trade" },
                      { title: "Contas apertadas", strategy: "Gerenciar capital de forma conservadora, focando em trades de alta probabilidade" },
                      { title: "Ansiedade", strategy: "Rotinas pré-trade para acalmar a mente e técnicas de respiração" },
                      { title: "Falta de disciplina", strategy: "Criar checklist diário rigoroso com recompensas e consequências" },
                      { title: "Sair do plano", strategy: "Auto-punição ou pausa forçada após cada desvio, revisão constante do plano" },
                    ].map((point, idx) => (
                      <Card key={idx} className="bg-red-50 border-red-200">
                        <CardContent className="pt-4">
                          <p className="font-bold text-red-900">{point.title}</p>
                          <p className="text-sm text-red-800">{point.strategy}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="bg-green-50 border-green-200">
                    <CardContent className="pt-6">
                      <p className="font-bold text-green-900 mb-2">DIAS BONS</p>
                      <p className="text-sm text-green-800">
                        "Hoje, a disciplina e a paciência foram recompensadas. Cada trade executado conforme o plano me aproxima da liberdade financeira."
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-red-50 border-red-200">
                    <CardContent className="pt-6">
                      <p className="font-bold text-red-900 mb-2">DIAS RUINS</p>
                      <p className="text-sm text-red-800">
                        "Um dia de aprendizado não é um dia perdido. Mantenho o foco no objetivo maior e volto mais forte amanhã."
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Contas */}
          <TabsContent value="contas" className="space-y-6">
            <AccountSelector />
          </TabsContent>

          {/* Tab: Ativos */}
          <TabsContent value="ativos" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  Ativos Operados
                </CardTitle>
                <CardDescription>5 ativos principais para operação</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { symbol: "EUR/USD", type: "Forex", session: "Sessão Europeia" },
                    { symbol: "USDJPY", type: "Forex", session: "Sessão Asiática" },
                    { symbol: "XAUUSD", type: "Commodity", session: "24 horas" },
                    { symbol: "NASDAQ", type: "Índice", session: "Sessão Americana" },
                    { symbol: "BTC USD", type: "Criptomoeda", session: "24 horas" },
                  ].map((asset) => (
                    <Card key={asset.symbol} className="border-l-4 border-l-blue-500">
                      <CardContent className="pt-6">
                        <p className="text-2xl font-bold text-primary">{asset.symbol}</p>
                        <p className="text-sm text-muted-foreground">{asset.type}</p>
                        <p className="text-xs text-muted-foreground mt-2">{asset.session}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Estratégia */}
          <TabsContent value="estrategia" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Checklist Operacional
                </CardTitle>
                <CardDescription>7 Regras Essenciais para Operação Disciplinada</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      number: "1",
                      title: "CHoCH Válido em HTF (H4, H2 ou H1)",
                      desc: "Um CHoCH válido é quando um LOW ou HIGH protegido é rompido. O LOW e HIGH protegido é feito quando o preço rompe uma região de HIGH (faz um LOW que é o último extremo antes desse rompimento) ou rompe uma região de LOW (faz um TOPO protegido que é o último HIGH extremo antes desse rompimento).",
                      color: "bg-blue-50 border-l-blue-500",
                    },
                    {
                      number: "2",
                      title: "Caixa de Gann em M30",
                      desc: "Traçada do início do movimento até o fim do CHoCH válido. Para vendas: do HIGH até o LOW. Para compras: do LOW até o HIGH. Utilizar apenas as regiões 0%, 50% e 100%.",
                      color: "bg-purple-50 border-l-purple-500",
                    },
                    {
                      number: "3",
                      title: "Orderblocks Descontados (50% da Gann)",
                      desc: "Apenas orderblocks abaixo da linha de 50% da Gann para compra, ou acima do 50% para venda. Quanto mais descontado, melhor a oportunidade.",
                      color: "bg-green-50 border-l-green-500",
                    },
                    {
                      number: "4",
                      title: "Order Blocks Válidos (H4, H2, H1 ou M30)",
                      desc: "Se o candle tiver muito pavil e pouco corpo, traçar o candle todo. Se tiver muito corpo e pouco pavil, traçar também o candle todo, buscando vender/comprar nos 50% dele.",
                      color: "bg-amber-50 border-l-amber-500",
                    },
                    {
                      number: "5",
                      title: "Entrada Sempre no 50% do Order Block",
                      desc: "Identificar ineficiências de HTF (H4, H2, H1) e entrar sempre no 50% da região de demanda ou oferta traçada ou do orderblock.",
                      color: "bg-red-50 border-l-red-500",
                    },
                    {
                      number: "6",
                      title: "Stop Loss com Folga",
                      desc: "Stop abaixo ou acima do Order Block ou ineficiência HTF no mínimo M30 traçado com um pouco de folga.",
                      color: "bg-orange-50 border-l-orange-500",
                    },
                    {
                      number: "7",
                      title: "Take Profit Mínimo 1:3",
                      desc: "Take profit sempre em 1:3 no mínimo. Relação risco-retorno obrigatória para viabilizar a operação.",
                      color: "bg-indigo-50 border-l-indigo-500",
                    },
                    {
                      number: "8",
                      title: "Tempo Gráfico Operacional em M15 ou M5",
                      desc: "Confirmar o tempo gráfico operacional em M15 ou M5 antes de executar a operação. Validação final antes da entrada.",
                      color: "bg-cyan-50 border-l-cyan-500",
                    },
                  ].map((item, idx) => (
                    <Card key={idx} className={`border-l-4 ${item.color}`}>
                      <CardContent className="pt-6">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm">
                            {item.number}
                          </div>
                          <div className="flex-1">
                            <p className="font-bold text-foreground">{item.title}</p>
                            <p className="text-sm text-foreground/80 mt-2">{item.desc}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Gestão */}
          <TabsContent value="gestao" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-primary" />
                  Gestão de Risco
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardContent className="pt-6">
                      <p className="text-3xl font-bold text-blue-600">1:3</p>
                      <p className="text-sm text-muted-foreground">R:R Mínimo</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-red-500">
                    <CardContent className="pt-6">
                      <p className="text-3xl font-bold text-red-600">2</p>
                      <p className="text-sm text-muted-foreground">Stops para Parar</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-green-500">
                    <CardContent className="pt-6">
                      <p className="text-3xl font-bold text-green-600">5</p>
                      <p className="text-sm text-muted-foreground">Ativos Monitorados</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Rotina */}
          <TabsContent value="rotina" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Rotina Diária de Operação
                </CardTitle>
                <CardDescription>Segunda a Sexta-feira - Regime de Meio Período</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[
                    {
                      period: "Manhã (6h-12h)",
                      icon: "🌅",
                      color: "bg-yellow-50 border-l-yellow-500",
                      tasks: [
                        "Verificar configuração do ambiente (PC, internet, plataforma)",
                        "Avaliar prontidão mental e emocional",
                        "Confirmar clareza sobre objetivos do dia",
                        "Análise HTF (H4, H2, H1) dos 5 ativos: EUR/USD, USDJPY, XAUUSD, NASDAQ, BTC USD",
                        "Identificar CHoCH válidos em HTF",
                        "Traçar Caixas de Gann em M30",
                        "Planejamento do dia: setup esperados, níveis críticos",
                        "Preparação mental e emocional para o dia",
                      ]
                    },
                    {
                      period: "Tarde (12h-18h)",
                      icon: "☀️",
                      color: "bg-orange-50 border-l-orange-500",
                      tasks: [
                        "Operações principais conforme setups planejados",
                        "Monitoramento contínuo dos 5 ativos",
                        "Identificação de Order Blocks descontados",
                        "Execução de entradas no 50% do OB",
                        "Gerenciamento de posições abertas",
                        "Acompanhamento de regiões traçadas ao longo do dia",
                        "Análise LTF (M30, M15, M5) para confirmação",
                        "Respeito rígido ao checklist operacional",
                      ]
                    },
                    {
                      period: "Noite (18h-22h)",
                      icon: "🌙",
                      color: "bg-blue-50 border-l-blue-500",
                      tasks: [
                        "Fechamento de posições abertas",
                        "Revisão detalhada de todos os trades do dia",
                        "Análise de erros: quais regras foram violadas?",
                        "Registrar trades no Diário com checklist emocional/racional",
                        "Upload de imagens pré-trading, trading e pós-trading",
                        "Cálculo de P&L do dia",
                        "Verificação de limite diário (2 wins ou 3 losses)",
                        "Planejamento para o próximo dia",
                        "Preparação mental para descanso",
                      ]
                    },
                  ].map((item, idx) => (
                    <Card key={idx} className={`border-l-4 ${item.color}`}>
                      <CardContent className="pt-6">
                        <div className="flex items-start gap-4">
                          <div className="text-3xl">{item.icon}</div>
                          <div className="flex-1">
                            <p className="font-bold text-foreground text-lg">{item.period}</p>
                            <ul className="mt-4 space-y-2">
                              {item.tasks.map((task, taskIdx) => (
                                <li key={taskIdx} className="flex items-start gap-2 text-sm text-foreground/80">
                                  <span className="text-primary font-bold mt-0.5">•</span>
                                  <span>{task}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {/* Limites Diários */}
                  <Card className="border-2 border-red-300 bg-red-50">
                    <CardContent className="pt-6">
                      <p className="font-bold text-red-900 mb-4">⚠️ Limites Diários Obrigatórios</p>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded border-l-4 border-l-red-500">
                          <p className="text-sm font-bold text-red-700">Máximo de Perdas</p>
                          <p className="text-2xl font-bold text-red-600 mt-2">3 Losses</p>
                          <p className="text-xs text-red-600 mt-1">Parar operações se atingir 3 perdas no dia</p>
                        </div>
                        <div className="bg-white p-4 rounded border-l-4 border-l-green-500">
                          <p className="text-sm font-bold text-green-700">Máximo de Ganhos</p>
                          <p className="text-2xl font-bold text-green-600 mt-2">2 Wins</p>
                          <p className="text-xs text-green-600 mt-1">Considerar parar após 2 vitórias consecutivas</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Dias de Operação */}
                  <Card className="border-2 border-blue-300 bg-blue-50">
                    <CardContent className="pt-6">
                      <p className="font-bold text-blue-900 mb-4">📅 Dias de Operação</p>
                      <div className="flex flex-wrap gap-2">
                        {['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'].map((day) => (
                          <span key={day} className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold">
                            {day}
                          </span>
                        ))}
                      </div>
                      <p className="text-sm text-blue-800 mt-4">Fim de semana: Descanso, análise e planejamento</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Alertas */}
          <TabsContent value="alertas" className="space-y-6">
            <NewsAlerts />
          </TabsContent>

          {/* Tab: Análises */}
          <TabsContent value="analises" className="space-y-6">
            <AnalysisHistory />
          </TabsContent>

          {/* Tab: Calculadora */}
          <TabsContent value="calculadora" className="space-y-6">
            <RiskCalculator />
          </TabsContent>

          {/* Tab: Diario */}
          <TabsContent value="diario" className="space-y-6">
            <TradeJournalEnhanced />
          </TabsContent>

          {/* Tab: Calendario */}
          <TabsContent value="calendario" className="space-y-6">
            <EconomicCalendar />
          </TabsContent>

          {/* Tab: Insights */}
          <TabsContent value="insights" className="space-y-6">
            <PerformanceDashboard />
            <AssetPerformanceAnalysis />
          </TabsContent>

          {/* Tab: Comparacao Enhanced */}
          <TabsContent value="comparacao-enhanced" className="space-y-6">
            <StrategyComparisonEnhanced trades={tradesUnified} />
          </TabsContent>

          {/* Tab: Relatorio Enhanced */}
          <TabsContent value="relatorio-enhanced" className="space-y-6">
            <ReportExportEnhanced trades={tradesUnified} />
          </TabsContent>

          <TabsContent value="validacao" className="space-y-6">
            <DailyValidation />
          </TabsContent>
        </Tabs>

        {/* Seção de Resumo Final - MOVIDA PARA O FINAL */}
        <Card className="mt-12 border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              Seu Operacional Estruturado
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-4">Um plano completo e disciplinado</h2>
                <p className="text-foreground/80 mb-6">
                  Para trading no mercado financeiro. Todas as suas regras, estratégias e rotinas em um único lugar.
                </p>
                <div className="flex gap-4">
                  <Button className="bg-primary hover:bg-primary/90" onClick={() => {
                    const element = document.querySelector('[role="tablist"]')?.parentElement;
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}>Visualizar Plano</Button>
                  <Button variant="outline" onClick={() => {
                    const link = document.createElement('a');
                    link.href = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663393391552/wuarKaydhRtVlTLn.pdf';
                    link.download = 'HACKTRADINGPLAN.pdf';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}>Exportar PDF</Button>
                </div>
              </div>
              <div className="rounded-lg overflow-hidden border border-border">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663393391552/BXPsiEYMeVxT8awNx3LM24/hero-trading-dashboard-76fPaom6HWvQbEK8ruhadn.webp"
                  alt="Trading Dashboard Hero"
                  className="w-full h-auto"
                />
              </div>
            </div>

            <Separator className="my-6" />

            <p className="text-sm text-foreground/80">
              Este plano foi estruturado para garantir disciplina, consistência e gestão rigorosa de risco. Cada trade deve seguir este plano de ação para que a vantagem lucrativa se concretize. Mantenha este plano próximo ao local onde você negocia para usá-lo como referência.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
