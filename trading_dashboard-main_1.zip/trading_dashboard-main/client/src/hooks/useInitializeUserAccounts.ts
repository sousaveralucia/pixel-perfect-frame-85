import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

/**
 * Hook para inicializar contas padrão para novos usuários
 * Cria 3 contas padrão (Conta 1, Conta 2, Conta 3) se o usuário não tiver nenhuma
 */
export function useInitializeUserAccounts() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const accountsQuery = trpc.accounts.list.useQuery(undefined, {
    enabled: !!user,
  });
  const createAccountMutation = trpc.accounts.create.useMutation();

  useEffect(() => {
    if (!user || accountsQuery.isLoading || accountsQuery.data === undefined) {
      return;
    }

    // Se o usuário não tem contas, criar as 3 contas padrão
    if (accountsQuery.data.length === 0) {
      const defaultAccounts = ["Conta 1", "Conta 2", "Conta 3"];
      
      defaultAccounts.forEach((accountName) => {
        createAccountMutation.mutate(
          { name: accountName },
          {
            onSuccess: () => {
              utils.accounts.list.invalidate();
            },
          }
        );
      });
    }
  }, [user, accountsQuery.data, accountsQuery.isLoading, createAccountMutation, utils]);

  return {
    accounts: accountsQuery.data || [],
    isLoading: accountsQuery.isLoading,
    isCreating: createAccountMutation.isPending,
  };
}
