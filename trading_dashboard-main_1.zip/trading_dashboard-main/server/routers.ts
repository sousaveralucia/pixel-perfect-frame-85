import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Trading Accounts
  accounts: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.getTradingAccountsByUserId(ctx.user.id)
    ),
    create: protectedProcedure
      .input(z.object({ name: z.string().min(1) }))
      .mutation(({ ctx, input }) =>
        db.createTradingAccount(ctx.user.id, input.name)
      ),
    update: protectedProcedure
      .input(z.object({ 
        accountId: z.number(), 
        name: z.string().optional(), 
        currentBalance: z.string().optional() 
      }))
      .mutation(({ input }) =>
        db.updateTradingAccount(input.accountId, {
          name: input.name,
          currentBalance: input.currentBalance,
        })
      ),
  }),

  // Trades
  trades: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.getTradesByUserId(ctx.user.id)
    ),
    listByAccount: protectedProcedure
      .input(z.object({ accountId: z.number() }))
      .query(({ input }) =>
        db.getTradesByAccountId(input.accountId)
      ),
    create: protectedProcedure
      .input(z.object({
        accountId: z.number(),
        asset: z.string(),
        entryPrice: z.string().optional(),
        stopLossPrice: z.string().optional(),
        takeProfitPrice: z.string().optional(),
        exitPrice: z.string().optional(),
        result: z.string().optional(),
        moneyResult: z.string().optional(),
        pips: z.string().optional(),
        ticks: z.number().optional(),
        riskReward: z.string().optional(),
        executedAt: z.date().optional(),
        session: z.string().optional(),
        isFavorite: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { ...tradeData } = input;
        return db.createTrade(ctx.user.id, tradeData as any);
      }),
    update: protectedProcedure
      .input(z.object({
        tradeId: z.number(),
        data: z.object({
          result: z.string().optional(),
          moneyResult: z.string().optional(),
          exitPrice: z.string().optional(),
          isFavorite: z.number().optional(),
          notes: z.string().optional(),
        }),
      }))
      .mutation(({ input }) =>
        db.updateTrade(input.tradeId, input.data)
      ),
    delete: protectedProcedure
      .input(z.object({ tradeId: z.number() }))
      .mutation(({ input }) =>
        db.deleteTrade(input.tradeId)
      ),
  }),

  // Analyses
  analyses: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.getAnalysesByUserId(ctx.user.id)
    ),
    create: protectedProcedure
      .input(z.object({
        asset: z.string(),
        description: z.string().optional(),
        imageUrl: z.string().optional(),
        status: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { ...analysisData } = input;
        return db.createAnalysis(ctx.user.id, analysisData as any);
      }),
    update: protectedProcedure
      .input(z.object({
        analysisId: z.number(),
        data: z.object({
          description: z.string().optional(),
          imageUrl: z.string().optional(),
          status: z.string().optional(),
        }),
      }))
      .mutation(({ input }) =>
        db.updateAnalysis(input.analysisId, input.data)
      ),
    delete: protectedProcedure
      .input(z.object({ analysisId: z.number() }))
      .mutation(({ input }) =>
        db.deleteAnalysis(input.analysisId)
      ),
  }),
});

export type AppRouter = typeof appRouter;
