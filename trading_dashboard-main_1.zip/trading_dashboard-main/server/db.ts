import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, trades, tradingAccounts, analyses, InsertTrade, InsertTradingAccount, InsertAnalysis } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Trading Accounts
export async function createTradingAccount(userId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(tradingAccounts).values({
    userId,
    name,
    currentBalance: "0",
    isActive: 1,
  });
  
  return result;
}

export async function getTradingAccountsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(tradingAccounts).where(eq(tradingAccounts.userId, userId));
}

export async function updateTradingAccount(accountId: number, data: Partial<InsertTradingAccount>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(tradingAccounts).set(data).where(eq(tradingAccounts.id, accountId));
}

// Trades
export async function createTrade(userId: number, trade: InsertTrade) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(trades).values({
    ...trade,
    userId,
  });
}

export async function getTradesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(trades).where(eq(trades.userId, userId));
}

export async function getTradesByAccountId(accountId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(trades).where(eq(trades.accountId, accountId));
}

export async function updateTrade(tradeId: number, data: Partial<InsertTrade>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(trades).set(data).where(eq(trades.id, tradeId));
}

export async function deleteTrade(tradeId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(trades).where(eq(trades.id, tradeId));
}

// Analyses
export async function createAnalysis(userId: number, analysis: InsertAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(analyses).values({
    ...analysis,
    userId,
  });
}

export async function getAnalysesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(analyses).where(eq(analyses.userId, userId));
}

export async function updateAnalysis(analysisId: number, data: Partial<InsertAnalysis>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(analyses).set(data).where(eq(analyses.id, analysisId));
}

export async function deleteAnalysis(analysisId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(analyses).where(eq(analyses.id, analysisId));
}
