# Trading Dashboard - TODO

## Sistema de Autenticação (Tarefa Atual)

- [x] Atualizar schema do banco de dados com tabelas para trades, contas e análises
- [x] Adicionar helpers de query no server/db.ts
- [x] Implementar routers tRPC para trades, contas e análises
- [x] Criar página de Login
- [x] Adicionar rota de login e proteção de rotas
- [x] Criar página de Cadastro
- [x] Implementar inicialização automática de contas padrão
- [x] Escrever testes de integração para autenticação
- [x] Testes passando com sucesso (8 testes)
- [ ] Migrar dados do localStorage para banco de dados
- [ ] Testar fluxo completo de autenticação em produção

## 🐛 Bugs Críticos a Corrigir (Sessão Atual)

- [x] Erro ao gerar relatório em PDF em Trades - CORRIGIDO: Adicionado try-catch melhorado, validado escopo de variáveis
- [x] Impossibilidade de deletar imagens em Análises (botão X não funciona) - CORRIGIDO: Botão X agora atualiza localStorage corretamente
- [x] Quebra de linha em campos de texto longos (Order Block, Fibonacci) no PDF de Análises - CORRIGIDO: Implementado splitTextToSize para quebra automática
- [x] Testar todos os relatórios após correções - TESTADO: Relatório gerado com sucesso

## Próximas Melhorias Sugeridas

- [ ] Integração com banco de dados para persistência de trades
- [ ] Sincronização de contas entre dispositivos
- [ ] Notificações em tempo real para limites de risco
- [ ] Exportação de relatórios em Excel
- [ ] Gráficos de performance com Chart.js
- [ ] Integração com APIs de preços em tempo real

## Status "Em Andamento" (Tarefa 1) ✅ CONCLUÍDO

- [x] Adicionar novo status "ongoing" aos trades
- [x] Atualizar modal de registro de trades com botão "Em Andamento"
- [x] Permitir salvar trades sem preço de saída
- [x] Atualizar relatórios para incluir trades em andamento
- [x] Implementar filtro para trades ONGOING

## Gerenciador de Contas (Tarefa 2) ✅ CONCLUÍDO

- [x] Criar interface de gerenciamento de contas
- [x] Permitir edição de nomes de contas
- [x] Adicionar ícone de edição para nomes
- [x] Sincronizar dados com localStorage

## Novo Tema Escuro (Tarefa 3) ✅ CONCLUÍDO

- [x] Atualizar variáveis CSS com cores: azul escuro (#1a2332), cinza (#4a5a6a), preto (#0f1419), laranja escuro (#d97706)
- [x] Aplicar novo tema em todos os componentes
- [x] Garantir contraste adequado para legibilidade
- [x] Tema consistente entre modo claro e escuro

## Correção do Pincel da Galeria (Tarefa 4) ✅ CONCLUÍDO

- [x] Corrigir offset do canvas para alinhar com o mouse
- [x] Implementar cálculo correto de escala (scaleX, scaleY)
- [x] Testar alinhamento em diferentes resoluções

## Edição de Cores do PDF (Tarefa 5) ✅ CONCLUÍDO

- [x] Criar componente PDFColorCustomizer
- [x] Permitir visualização prévia das cores
- [x] Salvar preferências de cores no localStorage
- [x] Suportar 8 cores customizáveis

## Sistema de 4 Checklists (Tarefa 6) ✅ CONCLUÍDO

- [x] Criar checklist "Emocional" com 3 perguntas essenciais
- [x] Renomear checklist anterior para "Rotina e Saúde"
- [x] Manter checklist "Operacional" como obrigatório (com ⚠️)
- [x] Adicionar 4º checklist "Racional" (Análise e Plano)
- [x] Atualizar interface do modal de trades com 4 seções
- [x] Adicionar 16 testes vitest para todas as funcionalidades
- [x] Todos os 24 testes passando com sucesso

## 🐛 Bug Crítico - Sobreposição de Texto em Análises (Nova Sessão)

- [x] Sobreposição de texto no PDF de Análises - CORRIGIDO
  - Problema: yPosition não era incrementado antes de desenhar texto quebrado
  - Solução: Adicionado yPosition += 6 antes de cada doc.text() com splitTextToSize
  - Testado: PDF gerado com sucesso, sem sobreposição de palavras


## 🆕 Exportação em Excel - Implementado com Sucesso

- [x] Criar utilitário de exportação Excel (excelExporter.ts) com XLSX.js
- [x] Implementar exportação de Trades em Excel com 11 colunas
- [x] Implementar exportação de Análises em Excel com 8 colunas
- [x] Implementar exportação de Relatório Completo em Excel com 3 abas (Resumo, Trades, Análises)
- [x] Adicionar botão "Exportar em Excel" em TradeJournalEnhanced
- [x] Adicionar botão "Exportar Excel" em AnalysisHistory
- [x] Adicionar botão "Gerar em Excel" em ReportExportEnhanced
- [x] Testar todas as 3 exportações com sucesso
